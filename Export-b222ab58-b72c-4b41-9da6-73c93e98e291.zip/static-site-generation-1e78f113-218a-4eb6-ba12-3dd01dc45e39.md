# static site generation

Date: Mar 21, 2019
Generators: forget about it),gatsby,react ssr
Status: Not Started

